# OliveConnect — Performance Dashboard

A React + TypeScript implementation of the OliveConnect Performance
Dashboard, built from the "Olive Field" design blueprint with full
glassmorphism.

## Stack

- **Next.js 16** (App Router) + **React 19** + **TypeScript 5**
- **Tailwind CSS 4** + **shadcn/ui** components
- **Recharts** for charts
- **Lucide** icons
- **Inter** + **Manrope** + **JetBrains Mono** fonts (via `next/font`)

## Quick start

```bash
# 1. Install dependencies (npm or bun — either works)
npm install
# or: bun install

# 2. Run the dev server
npm run dev
# or: bun run dev

# 3. Open the app
#   http://localhost:3000
```

The dashboard renders on the `/` route. No database or backend required —
all data is mocked in `src/lib/dashboard/mockData.ts`.

## Project structure

```
src/
├── app/
│   ├── globals.css         ← Olive Field tokens + glassmorphism utilities
│   ├── layout.tsx          ← Inter + Manrope fonts
│   └── page.tsx            ← renders <Dashboard />
├── components/
│   ├── ui/                 ← shadcn/ui primitives (preinstalled)
│   └── dashboard/
│       ├── Dashboard.tsx           ← top-level composition
│       ├── GlassCard.tsx           ← frosted-glass surface
│       ├── StatusBadge.tsx         ← generic status pill
│       ├── Sparkline.tsx           ← inline SVG sparkline
│       ├── Sidebar.tsx             ← role-aware nav
│       ├── TopBar.tsx              ← page header + date range pills
│       ├── KpiGrid.tsx             ← 4 KPI cards with deltas + sparklines
│       ├── RequestsByStatusChart   ← donut (Recharts)
│       ├── YieldByOrchardChart     ← horizontal bars
│       ├── CollectionDelaysChart   ← area line + 2 stat tiles
│       ├── BinFillRatesChart       ← vertical bars + target line
│       └── ActivityFeed.tsx        ← recent activity list
├── features/_shared/
│   └── statusStyles.ts     ← single source of truth for status → color
├── lib/
│   ├── utils.ts            ← cn() helper (clsx + tailwind-merge)
│   └── dashboard/
│       └── mockData.ts     ← static fixture matching the API contract
└── types/
    └── contract.ts         ← TS mirror of the OliveConnect API
```

## Design system

The "Olive Field" palette is defined as CSS variables in
`src/app/globals.css` (`:root` block) and mapped into Tailwind via the
`@theme inline` block. Use them as `bg-olive-600`, `text-ochre-500`,
`border-cream-200`, etc.

Status colors live in `src/features/_shared/statusStyles.ts`. **Always**
use the `*Styles` maps there — never invent new status colors.

Glassmorphism utilities (also in `globals.css`):

| Class         | Use for                                  |
| ------------- | ---------------------------------------- |
| `.glass`      | Default cards, chart panels              |
| `.glass-strong` | Modals, prominent surfaces             |
| `.glass-subtle` | Sidebar, top bar, inputs               |
| `.glass-nav`  | Sticky navigation                       |

Each sets `backdrop-filter: blur() saturate()` + a translucent white fill.

## Connecting to the real API

Replace the imports from `@/lib/dashboard/mockData` with TanStack Query
hooks that call the OliveConnect backend:

```ts
// Example: replace `mockSummary` with a live query
const { data: summary } = useQuery({
  queryKey: ["dashboard", "summary", { from, to }],
  queryFn: () =>
    fetch(`/api/v1/dashboard/summary?from=${from}&to=${to}`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then((r) => r.json()),
});
```

The response shapes already match `DashboardSummary`, `YieldByOrchard`,
`CollectionDelays`, and `BinFillRates` in `src/types/contract.ts`.

## Build for production

```bash
npm run build
npm run start
```

## Lint

```bash
npm run lint
```
