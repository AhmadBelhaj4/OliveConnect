// src/types/contract.ts
// Verbatim TypeScript mirror of the OliveConnect API contract.
// Source: docs/api-contract.md (project plan, sections 5–6).

export type Role =
  | "FARMER"
  | "COLLECTION_MANAGER"
  | "TEAM_LEADER"
  | "LOGISTICS_MANAGER"
  | "PRESS_MANAGER"
  | "ADMIN";

export type MaturityStatus =
  | "UNKNOWN"
  | "IMMATURE"
  | "APPROACHING"
  | "OPTIMAL"
  | "OVERRIPE";

export type HarvestType = "PLANNED" | "URGENT";

export type HarvestStatus =
  | "SUBMITTED"
  | "APPROVED"
  | "REJECTED"
  | "SCHEDULED"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "CANCELLED";

export type AlertType = "MATURITY" | "PEST" | "RAIN" | "OTHER";

export type AlertPriority = "LOW" | "MEDIUM" | "HIGH";
export type AlertStatus = "OPEN" | "ACKNOWLEDGED" | "RESOLVED" | "DISMISSED";

export type TourStatus =
  | "DRAFT"
  | "PLANNED"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "CANCELLED";

export type StopStatus = "PLANNED" | "COMPLETED";
export type ResourceStatus = "AVAILABLE" | "IN_USE" | "MAINTENANCE";

export type VehicleType = "TRACTOR" | "TRUCK";
export type EquipmentType = "NET" | "VIBRATOR" | "OTHER";
export type QualityGrade = "A" | "B" | "C";

export type NotificationType =
  | "REQUEST_APPROVED"
  | "REQUEST_REJECTED"
  | "TOUR_SCHEDULED"
  | "TOUR_CHANGED"
  | "COLLECTION_STARTED"
  | "COLLECTION_COMPLETED"
  | "ALERT_ACKNOWLEDGED"
  | "ALERT_RESOLVED"
  | "ALERT_DISMISSED";

// Dashboard responses (MEMBRE B)
export interface DashboardSummary {
  from: string;
  to: string;
  totalHarvestedKg: number;
  totalReceivedKg: number;
  completedTours: number;
  openAlerts: number;
  requestsByStatus: Record<HarvestStatus, number>;
}

export interface YieldByOrchardItem {
  orchardId: string;
  orchardName: string;
  totalHarvestedKg: number;
  collectionCount: number;
}

export interface YieldByOrchard {
  from: string;
  to: string;
  items: YieldByOrchardItem[];
}

export interface CollectionDelays {
  from: string;
  to: string;
  sampleSize: number;
  avgSubmittedToScheduledHours: number;
  avgScheduledToCompletedHours: number;
}

export interface BinFillRateItem {
  binId: string;
  binCode: string;
  capacityKg: number;
  receptionCount: number;
  avgFillRate: number; // 0..1
}

export interface BinFillRates {
  from: string;
  to: string;
  items: BinFillRateItem[];
}
