// src/components/dashboard/TopBar.tsx
// Page header with title, date-range pills, and perimeter select.

"use client";

import { Bell, Search, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const ranges = ["Today", "7d", "Nov", "30d"];

export function TopBar() {
  return (
    <header className="sticky top-0 z-30 -mx-4 px-4 py-3 mb-6 glass-nav border-x-0 border-t-0">
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 text-xs text-olive-700/70 mb-1">
            <span>Performance</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-olive-900">
            Performance — November 2026
          </h1>
          <p className="text-sm text-olive-700/80 mt-0.5 hidden sm:block">
            Aggregated yield, delays, and bin fill across the cooperative.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="hidden sm:flex items-center gap-2 h-9 px-3 rounded-md glass-subtle text-sm">
            <Search className="h-3.5 w-3.5 text-olive-700/70" />
            <input
              type="text"
              placeholder="Search orchards, tours…"
              className="bg-transparent outline-none text-sm text-olive-900 placeholder:text-olive-700/50 w-44"
            />
          </div>

          <div className="inline-flex rounded-md glass-subtle p-0.5">
            {ranges.map((r, i) => (
              <button
                key={r}
                className={cn(
                  "px-3 h-8 text-xs font-medium rounded transition-colors",
                  r === "Nov"
                    ? "bg-olive-600 text-cream-50"
                    : "text-olive-700 hover:bg-olive-900/5",
                )}
              >
                {r}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 h-9 px-3 rounded-md glass-subtle text-sm">
            <span className="text-olive-700/70 text-xs">Perimeter</span>
            <span className="text-olive-900 font-medium text-xs">All cooperative</span>
            <ChevronDown className="h-3.5 w-3.5 text-olive-700/70" />
          </div>

          <button
            className="relative h-9 w-9 grid place-items-center rounded-md glass-subtle text-olive-700 hover:bg-olive-900/5"
            aria-label="Notifications"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-ochre-500 ring-2 ring-white/70" />
          </button>
        </div>
      </div>
    </header>
  );
}
