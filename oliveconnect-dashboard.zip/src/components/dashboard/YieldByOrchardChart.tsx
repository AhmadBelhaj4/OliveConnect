// src/components/dashboard/YieldByOrchardChart.tsx
// Horizontal bar chart of top-yielding orchards.

"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  Cell,
  CellProps,
} from "recharts";
import { GlassCard } from "./GlassCard";
import { mockYieldByOrchard } from "@/lib/dashboard/mockData";

export function YieldByOrchardChart() {
  const rows = [...mockYieldByOrchard.items]
    .sort((a, b) => b.totalHarvestedKg - a.totalHarvestedKg)
    .slice(0, 7)
    .reverse(); // so the largest is at the top of a vertical-layout chart

  const max = Math.max(...rows.map((r) => r.totalHarvestedKg));

  return (
    <GlassCard hover className="p-5 h-full">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h2 className="font-display font-semibold text-base text-olive-900">
            Yield by orchard
          </h2>
          <p className="text-xs text-olive-700/70 mt-0.5">
            Top {rows.length} · November 2026
          </p>
        </div>
      </div>

      <div style={{ height: Math.max(220, rows.length * 36) }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={rows}
            layout="vertical"
            margin={{ left: 4, right: 16, top: 4, bottom: 4 }}
            barCategoryGap={8}
          >
            <XAxis
              type="number"
              tick={{ fontSize: 10, fill: "#8b917c" }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v) => `${(v / 1000).toFixed(1)}t`}
            />
            <YAxis
              type="category"
              dataKey="orchardName"
              tick={{ fontSize: 11, fill: "#5e6650" }}
              axisLine={false}
              tickLine={false}
              width={120}
            />
            <Tooltip
              cursor={{ fill: "rgba(74,107,42,0.08)" }}
              content={({ active, payload }) => {
                if (!active || !payload?.length) return null;
                const p = payload[0].payload as (typeof rows)[number];
                return (
                  <div
                    className="rounded-md px-2.5 py-1.5 text-xs shadow-md"
                    style={{
                      background: "rgba(255,255,255,0.95)",
                      border: "1px solid rgba(229,223,207,0.8)",
                      backdropFilter: "blur(8px)",
                    }}
                  >
                    <div className="font-medium text-olive-900">
                      {p.orchardName}
                    </div>
                    <div className="text-olive-700 mt-0.5 tabnum">
                      {p.totalHarvestedKg.toLocaleString()} kg ·{" "}
                      {p.collectionCount} collection
                      {p.collectionCount > 1 ? "s" : ""}
                    </div>
                  </div>
                );
              }}
            />
            <Bar dataKey="totalHarvestedKg" radius={[0, 4, 4, 0]}>
              {rows.map((r, i) => {
                // darkest for the top performer, lighter below
                const ratio = r.totalHarvestedKg / max;
                const color =
                  ratio > 0.85
                    ? "#4a6b2a"
                    : ratio > 0.6
                      ? "#6b8e3f"
                      : ratio > 0.4
                        ? "#8fae5c"
                        : "#a8be72";
                return <Cell key={r.orchardId} fill={color} />;
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </GlassCard>
  );
}
