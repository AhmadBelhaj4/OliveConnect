// src/components/dashboard/Dashboard.tsx
// Top-level dashboard composition: sidebar + top bar + KPI grid +
// 2x2 chart grid + activity feed.

"use client";

import { Sidebar } from "./Sidebar";
import { TopBar } from "./TopBar";
import { KpiGrid } from "./KpiGrid";
import { RequestsByStatusChart } from "./RequestsByStatusChart";
import { YieldByOrchardChart } from "./YieldByOrchardChart";
import { CollectionDelaysChart } from "./CollectionDelaysChart";
import { BinFillRatesChart } from "./BinFillRatesChart";
import { ActivityFeed } from "./ActivityFeed";

export function Dashboard() {
  return (
    <div className="min-h-screen flex flex-col">
      <div className="max-w-[1400px] w-full mx-auto px-4 sm:px-6 py-4 flex gap-6 flex-1">
        <Sidebar />
        <main className="flex-1 min-w-0 flex flex-col">
          <TopBar />
          <KpiGrid />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
            <RequestsByStatusChart />
            <YieldByOrchardChart />
            <CollectionDelaysChart />
            <BinFillRatesChart />
          </div>
          <ActivityFeed />
        </main>
      </div>
      <footer className="mt-auto py-6 text-center text-xs text-olive-700/60">
        OliveConnect · Performance Dashboard · React 18 + TypeScript + Tailwind
        CSS · "Olive Field" style with glassmorphism
      </footer>
    </div>
  );
}
