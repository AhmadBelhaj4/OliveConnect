// src/components/dashboard/BinFillRatesChart.tsx
// Vertical bar chart of bin fill rates with target line at 0.85.

"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  ReferenceLine,
  Cell,
} from "recharts";
import { GlassCard } from "./GlassCard";
import { mockBinFillRates } from "@/lib/dashboard/mockData";

const TARGET = 0.85;

export function BinFillRatesChart() {
  const data = mockBinFillRates.items.map((b) => ({
    ...b,
    aboveTarget: b.avgFillRate >= TARGET,
  }));

  const avgFill =
    data.reduce((s, d) => s + d.avgFillRate, 0) / data.length;

  return (
    <GlassCard hover className="p-5 h-full">
      <div className="flex items-start justify-between mb-3 flex-wrap gap-2">
        <div>
          <h2 className="font-display font-semibold text-base text-olive-900">
            Bin fill rates
          </h2>
          <p className="text-xs text-olive-700/70 mt-0.5">
            Average fill per bin · target {TARGET.toFixed(2)}
          </p>
        </div>
        <span
          className="inline-flex items-center gap-1.5 text-xs font-medium px-2 py-1 rounded-full"
          style={{
            color: avgFill >= TARGET ? "#2e7d32" : "#b45309",
            backgroundColor: avgFill >= TARGET ? "#d1f0d3" : "#fef3c7",
          }}
        >
          <span
            className="h-1.5 w-1.5 rounded-full"
            style={{
              backgroundColor: avgFill >= TARGET ? "#2e7d32" : "#b45309",
            }}
          />
          Avg {(avgFill * 100).toFixed(0)}%
        </span>
      </div>

      <div style={{ height: 200 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{ left: 8, right: 12, top: 8, bottom: 0 }}
            barCategoryGap={12}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(74,107,42,0.1)"
              vertical={false}
            />
            <XAxis
              dataKey="binCode"
              tick={{ fontSize: 10, fill: "#8b917c" }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              domain={[0, 1]}
              tick={{ fontSize: 10, fill: "#8b917c" }}
              axisLine={false}
              tickLine={false}
              width={32}
              tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
            />
            <ReferenceLine
              y={TARGET}
              stroke="#b45309"
              strokeDasharray="4 3"
              strokeWidth={1}
              label={{
                value: `target ${TARGET}`,
                position: "insideTopRight",
                fill: "#b45309",
                fontSize: 10,
              }}
            />
            <Tooltip
              cursor={{ fill: "rgba(74,107,42,0.08)" }}
              content={({ active, payload }) => {
                if (!active || !payload?.length) return null;
                const p = payload[0].payload as (typeof data)[number];
                return (
                  <div
                    className="rounded-md px-2.5 py-1.5 text-xs shadow-md"
                    style={{
                      background: "rgba(255,255,255,0.95)",
                      border: "1px solid rgba(229,223,207,0.8)",
                      backdropFilter: "blur(8px)",
                    }}
                  >
                    <div className="font-medium text-olive-900">
                      {p.binCode}
                    </div>
                    <div className="text-olive-700 mt-0.5 tabnum">
                      Fill rate: {(p.avgFillRate * 100).toFixed(0)}% ·{" "}
                      {p.receptionCount} receptions
                    </div>
                    <div className="text-olive-700/70 text-[10px] mt-0.5">
                      Capacity: {p.capacityKg} kg
                    </div>
                  </div>
                );
              }}
            />
            <Bar dataKey="avgFillRate" radius={[4, 4, 0, 0]}>
              {data.map((d) => (
                <Cell
                  key={d.binId}
                  fill={d.aboveTarget ? "#4a6b2a" : "#8fae5c"}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </GlassCard>
  );
}
