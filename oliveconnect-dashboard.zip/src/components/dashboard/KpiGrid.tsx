// src/components/dashboard/KpiGrid.tsx
// Four KPI cards with values, deltas, and inline sparklines.

"use client";

import { cn } from "@/lib/utils";
import { GlassCard } from "./GlassCard";
import { Sparkline } from "./Sparkline";
import {
  Wheat,
  Factory,
  Route,
  TriangleAlert,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from "lucide-react";
import { mockSummary } from "@/lib/dashboard/mockData";

type Direction = "up" | "down" | "flat";

interface Kpi {
  label: string;
  value: number;
  unit?: string;
  decimals?: number;
  delta: { value: string; direction: Direction };
  positiveDirection: "up" | "down"; // for some metrics, down = good
  icon: React.ComponentType<{ className?: string }>;
  iconBg: string;
  iconColor: string;
  sparkColor: string;
  sparkData: number[];
}

const kpis: Kpi[] = [
  {
    label: "Total harvested",
    value: mockSummary.totalHarvestedKg,
    unit: "t",
    decimals: 1,
    delta: { value: "+12% vs last month", direction: "up" },
    positiveDirection: "up",
    icon: Wheat,
    iconBg: "rgba(74,107,42,0.15)",
    iconColor: "#4a6b2a",
    sparkColor: "#4a6b2a",
    sparkData: [12, 14, 11, 16, 14, 18, 17, 20, 19, 22, 21, 24, 23, 26, 28, 27, 30, 32],
  },
  {
    label: "Total received",
    value: mockSummary.totalReceivedKg,
    unit: "t",
    decimals: 1,
    delta: { value: "+8% vs last month", direction: "up" },
    positiveDirection: "up",
    icon: Factory,
    iconBg: "rgba(74,107,42,0.15)",
    iconColor: "#4a6b2a",
    sparkColor: "#6b8e3f",
    sparkData: [11, 13, 12, 15, 14, 17, 16, 19, 18, 21, 20, 23, 22, 25, 27, 26, 28, 30],
  },
  {
    label: "Completed tours",
    value: mockSummary.completedTours,
    delta: { value: "−2 vs last month", direction: "down" },
    positiveDirection: "up",
    icon: Route,
    iconBg: "rgba(201,150,47,0.15)",
    iconColor: "#b07f1f",
    sparkColor: "#c9962f",
    sparkData: [2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 1, 2, 1, 0, 1, 1, 0],
  },
  {
    label: "Open alerts",
    value: mockSummary.openAlerts,
    delta: { value: "+1 this week", direction: "up" },
    positiveDirection: "down",
    icon: TriangleAlert,
    iconBg: "rgba(179,58,58,0.15)",
    iconColor: "#b33a3a",
    sparkColor: "#b33a3a",
    sparkData: [1, 2, 1, 2, 3, 2, 1, 2, 3, 2, 1, 1, 2, 3, 4, 3, 2, 3],
  },
];

export function KpiGrid() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {kpis.map((k) => (
        <KpiCard key={k.label} kpi={k} />
      ))}
    </div>
  );
}

function KpiCard({ kpi }: { kpi: Kpi }) {
  const Icon = kpi.icon;
  const isGoodDirection =
    kpi.delta.direction === "flat"
      ? true
      : kpi.delta.direction === kpi.positiveDirection;
  const deltaColor = isGoodDirection ? "#2e7d32" : "#b33a3a";
  const DeltaIcon =
    kpi.delta.direction === "up"
      ? ArrowUpRight
      : kpi.delta.direction === "down"
        ? ArrowDownRight
        : Minus;

  const displayValue =
    kpi.unit === "t"
      ? (kpi.value / 1000).toFixed(kpi.decimals ?? 1)
      : kpi.value.toLocaleString();

  return (
    <GlassCard hover className="p-5">
      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-[11px] font-medium uppercase tracking-wide text-olive-700/70">
            {kpi.label}
          </p>
          <p className="mt-2 font-display text-3xl font-bold tabnum text-olive-900">
            {displayValue}
            {kpi.unit && (
              <span className="ml-1 text-base font-medium text-olive-700/70">
                {kpi.unit}
              </span>
            )}
          </p>
        </div>
        <div
          className="h-9 w-9 rounded-md grid place-items-center shrink-0"
          style={{ backgroundColor: kpi.iconBg, color: kpi.iconColor }}
        >
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between gap-2">
        <span
          className="inline-flex items-center gap-1 text-xs font-medium min-w-0"
          style={{ color: deltaColor }}
        >
          <DeltaIcon className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate">{kpi.delta.value}</span>
        </span>
        <Sparkline data={kpi.sparkData} color={kpi.sparkColor} width={56} height={18} />
      </div>
    </GlassCard>
  );
}
