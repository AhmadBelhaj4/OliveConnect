// src/components/dashboard/ActivityFeed.tsx
// Recent activity list — each row uses a colored glass tile icon.

"use client";

import { GlassCard } from "./GlassCard";
import { Check, Package, TriangleAlert, Plus } from "lucide-react";
import { mockActivity, type ActivityItem } from "@/lib/dashboard/mockData";

const iconMap: Record<
  ActivityItem["icon"],
  React.ComponentType<{ className?: string }>
> = {
  check: Check,
  package: Package,
  alert: TriangleAlert,
  plus: Plus,
};

export function ActivityFeed() {
  return (
    <GlassCard hover className="p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display font-semibold text-base text-olive-900">
          Recent activity
        </h2>
        <button className="text-xs text-olive-700 hover:text-olive-900 transition-colors">
          View all
        </button>
      </div>
      <ol className="space-y-3">
        {mockActivity.map((item) => {
          const Icon = iconMap[item.icon];
          return (
            <li key={item.id} className="flex items-start gap-3">
              <div
                className="h-8 w-8 rounded-md grid place-items-center shrink-0"
                style={{
                  backgroundColor: item.iconBg,
                  color: item.iconColor,
                }}
              >
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-olive-900">
                  <span className="font-medium">{item.title}</span>{" "}
                  <span className="text-olive-700">{item.description}</span>
                </p>
              </div>
              <span className="text-xs text-olive-700/70 shrink-0">
                {item.timeAgo}
              </span>
            </li>
          );
        })}
      </ol>
    </GlassCard>
  );
}
