// src/components/dashboard/CollectionDelaysChart.tsx
// Two stat tiles + a smooth area line showing delays over the month.

"use client";

import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { GlassCard } from "./GlassCard";
import { mockCollectionDelays, delaySeries } from "@/lib/dashboard/mockData";

export function CollectionDelaysChart() {
  return (
    <GlassCard hover className="p-5 h-full">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h2 className="font-display font-semibold text-base text-olive-900">
            Collection delays
          </h2>
          <p className="text-xs text-olive-700/70 mt-0.5">
            Hours · {mockCollectionDelays.sampleSize} samples this period
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-3">
        <StatTile
          label="Submitted → Scheduled"
          value={mockCollectionDelays.avgSubmittedToScheduledHours.toFixed(1)}
          unit="h"
        />
        <StatTile
          label="Scheduled → Completed"
          value={mockCollectionDelays.avgScheduledToCompletedHours.toFixed(1)}
          unit="h"
        />
      </div>

      <div style={{ height: 140 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={delaySeries}
            margin={{ left: 8, right: 12, top: 4, bottom: 0 }}
          >
            <defs>
              <linearGradient id="delayGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#4a6b2a" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#4a6b2a" stopOpacity="0" />
              </linearGradient>
            </defs>
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(74,107,42,0.1)"
              vertical={false}
            />
            <XAxis
              dataKey="day"
              tick={{ fontSize: 10, fill: "#8b917c" }}
              axisLine={false}
              tickLine={false}
              interval={3}
            />
            <YAxis
              tick={{ fontSize: 10, fill: "#8b917c" }}
              axisLine={false}
              tickLine={false}
              width={28}
              tickFormatter={(v) => `${v}h`}
            />
            <Tooltip
              cursor={{ stroke: "rgba(74,107,42,0.3)", strokeWidth: 1 }}
              content={({ active, payload, label }) => {
                if (!active || !payload?.length) return null;
                return (
                  <div
                    className="rounded-md px-2.5 py-1.5 text-xs shadow-md"
                    style={{
                      background: "rgba(255,255,255,0.95)",
                      border: "1px solid rgba(229,223,207,0.8)",
                      backdropFilter: "blur(8px)",
                    }}
                  >
                    <div className="font-medium text-olive-900">{label}</div>
                    <div className="text-olive-700 mt-0.5 tabnum">
                      {payload[0].value as number} h scheduled → completed
                    </div>
                  </div>
                );
              }}
            />
            <Area
              type="monotone"
              dataKey="scheduledToCompleted"
              stroke="#4a6b2a"
              strokeWidth={2}
              fill="url(#delayGrad)"
              dot={false}
              activeDot={{ r: 4, fill: "#4a6b2a", stroke: "#fff", strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </GlassCard>
  );
}

function StatTile({
  label,
  value,
  unit,
}: {
  label: string;
  value: string;
  unit: string;
}) {
  return (
    <div className="rounded-md bg-olive-900/5 border border-olive-900/10 p-3">
      <p className="text-[10px] uppercase tracking-wide text-olive-700/70 leading-tight">
        {label}
      </p>
      <p className="mt-1 font-display text-2xl font-bold tabnum text-olive-900">
        {value}
        <span className="text-sm font-medium text-olive-700/70 ml-1">{unit}</span>
      </p>
    </div>
  );
}
