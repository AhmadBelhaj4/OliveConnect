// src/components/dashboard/Sidebar.tsx
// Role-aware vertical nav. Only "Dashboard" is active in this showcase.

"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";
import { GlassCard } from "./GlassCard";
import {
  Inbox,
  Route,
  TriangleAlert,
  Map,
  BarChart3,
  Boxes,
  CalendarCheck,
  Factory,
  ClipboardCheck,
  Users,
  FileUp,
  TreePine,
  Package,
  Bell,
} from "lucide-react";

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  active?: boolean;
  badge?: number;
}

const navItems: NavItem[] = [
  { label: "Requests queue", href: "#", icon: Inbox },
  { label: "Tours", href: "#", icon: Route },
  { label: "Field alerts", href: "#", icon: TriangleAlert, badge: 3 },
  { label: "Operational map", href: "#", icon: Map },
  {
    label: "Dashboard",
    href: "#",
    icon: BarChart3,
    active: true,
  },
];

const secondary: NavItem[] = [
  { label: "Resources", href: "#", icon: Boxes },
  { label: "Availability", href: "#", icon: CalendarCheck },
  { label: "Presses", href: "#", icon: Factory },
  { label: "Receptions", href: "#", icon: ClipboardCheck },
];

const admin: NavItem[] = [
  { label: "Users", href: "#", icon: Users },
  { label: "Imports", href: "#", icon: FileUp },
];

export function Sidebar() {
  return (
    <aside className="hidden lg:flex w-60 shrink-0 sticky top-[88px] self-start">
      <GlassCard variant="subtle" className="w-full p-3 rounded-2xl">
        <div className="flex items-center gap-2.5 px-2 py-2 mb-3">
          <div className="h-9 w-9 rounded-lg bg-olive-600 text-cream-50 grid place-items-center font-display font-bold text-sm">
            OC
          </div>
          <div className="leading-tight">
            <div className="font-display font-semibold text-sm text-olive-900">
              OliveConnect
            </div>
            <div className="text-[10px] text-olive-700/70 uppercase tracking-wide">
              Coll. Manager
            </div>
          </div>
        </div>

        <nav className="space-y-0.5">
          {navItems.map((item) => (
            <NavRow key={item.label} item={item} />
          ))}
        </nav>

        <div className="mt-4 mb-1.5 px-2 text-[10px] font-medium uppercase tracking-wide text-olive-700/60">
          Logistics
        </div>
        <nav className="space-y-0.5">
          {secondary.map((item) => (
            <NavRow key={item.label} item={item} />
          ))}
        </nav>

        <div className="mt-4 mb-1.5 px-2 text-[10px] font-medium uppercase tracking-wide text-olive-700/60">
          Administration
        </div>
        <nav className="space-y-0.5">
          {admin.map((item) => (
            <NavRow key={item.label} item={item} />
          ))}
        </nav>

        <div className="mt-4 pt-3 border-t border-olive-900/10 px-2">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-olive-500 to-olive-700 text-cream-50 grid place-items-center text-xs font-semibold">
              RC
            </div>
            <div className="leading-tight flex-1 min-w-0">
              <div className="text-xs font-medium text-olive-900 truncate">
                Resp. Collecte
              </div>
              <div className="text-[10px] text-olive-700/70 truncate">
                r.collecte@coop.tn
              </div>
            </div>
          </div>
        </div>
      </GlassCard>
    </aside>
  );
}

function NavRow({ item }: { item: NavItem }) {
  const Icon = item.icon;
  return (
    <Link
      href={item.href}
      className={cn(
        "flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm transition-colors",
        item.active
          ? "bg-olive-600/15 text-olive-900 font-medium"
          : "text-olive-700 hover:bg-olive-900/5",
      )}
    >
      <Icon className="h-4 w-4 shrink-0" />
      <span className="flex-1 truncate">{item.label}</span>
      {item.badge && (
        <span className="text-[10px] font-medium text-cream-50 bg-ochre-500 rounded-full px-1.5 py-0.5">
          {item.badge}
        </span>
      )}
    </Link>
  );
}
