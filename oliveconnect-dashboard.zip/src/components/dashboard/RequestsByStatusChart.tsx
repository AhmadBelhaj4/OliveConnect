// src/components/dashboard/RequestsByStatusChart.tsx
// Donut chart of harvest requests grouped by status, using the
// statusStyles palette as the single source of truth for colors.

"use client";

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { GlassCard } from "./GlassCard";
import { harvestStatusStyles } from "@/features/_shared/statusStyles";
import type { HarvestStatus } from "@/types/contract";
import { mockSummary } from "@/lib/dashboard/mockData";

const ORDER: HarvestStatus[] = [
  "SUBMITTED",
  "APPROVED",
  "SCHEDULED",
  "IN_PROGRESS",
  "COMPLETED",
  "REJECTED",
  "CANCELLED",
];

export function RequestsByStatusChart() {
  const data = ORDER.map((k) => ({
    name: harvestStatusStyles[k].label,
    value: mockSummary.requestsByStatus[k],
    bg: harvestStatusStyles[k].bg,
    fg: harvestStatusStyles[k].fg,
  })).filter((d) => d.value > 0);

  const total = data.reduce((s, d) => s + d.value, 0);

  return (
    <GlassCard hover className="p-5 h-full">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h2 className="font-display font-semibold text-base text-olive-900">
            Requests by status
          </h2>
          <p className="text-xs text-olive-700/70 mt-0.5">
            {total} total this period
          </p>
        </div>
      </div>

      <div className="flex items-center gap-5 flex-col sm:flex-row">
        <div className="relative w-36 h-36 shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="name"
                innerRadius={42}
                outerRadius={68}
                paddingAngle={2}
                stroke="none"
              >
                {data.map((d) => (
                  <Cell key={d.name} fill={d.bg} />
                ))}
              </Pie>
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const p = payload[0].payload as (typeof data)[number];
                  return (
                    <div
                      className="rounded-md px-2.5 py-1.5 text-xs shadow-md"
                      style={{
                        background: "rgba(255,255,255,0.95)",
                        border: "1px solid rgba(229,223,207,0.8)",
                        backdropFilter: "blur(8px)",
                      }}
                    >
                      <div className="flex items-center gap-1.5">
                        <span
                          className="h-2 w-2 rounded-full"
                          style={{ background: p.bg }}
                        />
                        <span className="font-medium text-olive-900">
                          {p.name}
                        </span>
                      </div>
                      <div className="text-olive-700 mt-0.5 tabnum">
                        {p.value} ·{" "}
                        {((p.value / total) * 100).toFixed(0)}%
                      </div>
                    </div>
                  );
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 grid place-items-center pointer-events-none">
            <div className="text-center">
              <p className="font-display text-2xl font-bold tabnum text-olive-900">
                {total}
              </p>
              <p className="text-[10px] text-olive-700/70 uppercase tracking-wide">
                total
              </p>
            </div>
          </div>
        </div>

        <ul className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-xs w-full">
          {data.map((d) => (
            <li
              key={d.name}
              className="flex items-center justify-between gap-2"
            >
              <span className="flex items-center gap-2 text-olive-700">
                <span
                  className="h-2.5 w-2.5 rounded-full shrink-0"
                  style={{ background: d.bg, outline: `1px solid ${d.fg}33` }}
                />
                <span className="truncate">{d.name}</span>
              </span>
              <span className="tabnum font-medium text-olive-900 shrink-0">
                {d.value}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </GlassCard>
  );
}
