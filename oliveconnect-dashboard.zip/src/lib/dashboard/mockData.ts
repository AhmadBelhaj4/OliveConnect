// src/lib/dashboard/mockData.ts
// Static fixture matching the dashboard contract examples.
// In production these come from:
//   GET /api/v1/dashboard/{summary|yield-by-orchard|collection-delays|bin-fill-rates}?from=&to=

import type {
  DashboardSummary,
  YieldByOrchard,
  CollectionDelays,
  BinFillRates,
} from "@/types/contract";

export const mockSummary: DashboardSummary = {
  from: "2026-11-01",
  to: "2026-11-30",
  totalHarvestedKg: 18450.5,
  totalReceivedKg: 17980.0,
  completedTours: 12,
  openAlerts: 3,
  requestsByStatus: {
    SUBMITTED: 4,
    APPROVED: 2,
    SCHEDULED: 5,
    IN_PROGRESS: 1,
    COMPLETED: 20,
    REJECTED: 1,
    CANCELLED: 2,
  },
};

export const mockYieldByOrchard: YieldByOrchard = {
  from: "2026-11-01",
  to: "2026-11-30",
  items: [
    { orchardId: "6741a1c2e4b0a1b2c3d4e5f6", orchardName: "North Orchard", totalHarvestedKg: 4200, collectionCount: 3 },
    { orchardId: "6741a1c2e4b0a1b2c3d4e5f7", orchardName: "East Plot", totalHarvestedKg: 3400, collectionCount: 2 },
    { orchardId: "6741a1c2e4b0a1b2c3d4e5f8", orchardName: "Hillside", totalHarvestedKg: 2900, collectionCount: 2 },
    { orchardId: "6741a1c2e4b0a1b2c3d4e5f9", orchardName: "River Field", totalHarvestedKg: 2500, collectionCount: 1 },
    { orchardId: "6741a1c2e4b0a1b2c3d4e5fa", orchardName: "South Orchard", totalHarvestedKg: 2000, collectionCount: 2 },
    { orchardId: "6741a1c2e4b0a1b2c3d4e5fb", orchardName: "Old Plot", totalHarvestedKg: 1500, collectionCount: 1 },
    { orchardId: "6741a1c2e4b0a1b2c3d4e5fc", orchardName: "West Plot", totalHarvestedKg: 900, collectionCount: 1 },
  ],
};

export const mockCollectionDelays: CollectionDelays = {
  from: "2026-11-01",
  to: "2026-11-30",
  sampleSize: 18,
  avgSubmittedToScheduledHours: 26.4,
  avgScheduledToCompletedHours: 52.1,
};

// Sparkline data for KPI cards — last 30 days
export const harvestedSparkline = [12, 14, 11, 16, 14, 18, 17, 20, 19, 22, 21, 24, 23, 26, 28, 27, 30, 32];
export const receivedSparkline = [11, 13, 12, 15, 14, 17, 16, 19, 18, 21, 20, 23, 22, 25, 27, 26, 28, 30];
export const toursSparkline = [2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 1, 2, 1, 0, 1, 1, 0];
export const alertsSparkline = [1, 2, 1, 2, 3, 2, 1, 2, 3, 2, 1, 1, 2, 3, 4, 3, 2, 3];

// Synthetic per-day delay series for the line chart
export const delaySeries = [
  { day: "Nov 01", scheduledToCompleted: 58 },
  { day: "Nov 03", scheduledToCompleted: 54 },
  { day: "Nov 05", scheduledToCompleted: 60 },
  { day: "Nov 07", scheduledToCompleted: 50 },
  { day: "Nov 09", scheduledToCompleted: 48 },
  { day: "Nov 11", scheduledToCompleted: 52 },
  { day: "Nov 13", scheduledToCompleted: 46 },
  { day: "Nov 15", scheduledToCompleted: 44 },
  { day: "Nov 17", scheduledToCompleted: 50 },
  { day: "Nov 19", scheduledToCompleted: 42 },
  { day: "Nov 21", scheduledToCompleted: 40 },
  { day: "Nov 23", scheduledToCompleted: 38 },
  { day: "Nov 25", scheduledToCompleted: 44 },
  { day: "Nov 27", scheduledToCompleted: 36 },
  { day: "Nov 29", scheduledToCompleted: 34 },
];

export const mockBinFillRates: BinFillRates = {
  from: "2026-11-01",
  to: "2026-11-30",
  items: [
    { binId: "1", binCode: "BIN-014", capacityKg: 500, receptionCount: 6, avgFillRate: 0.87 },
    { binId: "2", binCode: "BIN-015", capacityKg: 500, receptionCount: 5, avgFillRate: 0.91 },
    { binId: "3", binCode: "BIN-016", capacityKg: 500, receptionCount: 4, avgFillRate: 0.78 },
    { binId: "4", binCode: "BIN-017", capacityKg: 500, receptionCount: 7, avgFillRate: 0.95 },
    { binId: "5", binCode: "BIN-018", capacityKg: 500, receptionCount: 3, avgFillRate: 0.72 },
    { binId: "6", binCode: "BIN-019", capacityKg: 500, receptionCount: 5, avgFillRate: 0.89 },
    { binId: "7", binCode: "BIN-020", capacityKg: 500, receptionCount: 4, avgFillRate: 0.80 },
  ],
};

export interface ActivityItem {
  id: string;
  icon: "check" | "package" | "alert" | "plus";
  iconBg: string;
  iconColor: string;
  title: string;
  description: string;
  timeAgo: string;
}

export const mockActivity: ActivityItem[] = [
  {
    id: "1",
    icon: "check",
    iconBg: "rgba(74,107,42,0.15)",
    iconColor: "#4a6b2a",
    title: "Tour #4521 completed",
    description: "2,380 kg · North Orchard · Team leader: Sami Trabelsi",
    timeAgo: "just now",
  },
  {
    id: "2",
    icon: "package",
    iconBg: "rgba(74,107,42,0.15)",
    iconColor: "#4a6b2a",
    title: "Press reception",
    description: "Grade A · 2,380 kg · Pressoir de la coopérative",
    timeAgo: "2 min ago",
  },
  {
    id: "3",
    icon: "alert",
    iconBg: "rgba(180,83,9,0.15)",
    iconColor: "#b45309",
    title: "Alert acknowledged",
    description: "PEST · South Orchard · resolution note pending",
    timeAgo: "18 min ago",
  },
  {
    id: "4",
    icon: "plus",
    iconBg: "rgba(201,150,47,0.15)",
    iconColor: "#b07f1f",
    title: "New harvest request",
    description: "South Orchard · 1,200 kg · PLANNED · 2026-11-22",
    timeAgo: "3 h ago",
  },
];
