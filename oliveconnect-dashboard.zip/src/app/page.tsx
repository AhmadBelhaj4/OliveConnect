// src/app/page.tsx — OliveConnect Performance Dashboard (glassmorphism)

import { Dashboard } from "@/components/dashboard/Dashboard";

export default function Home() {
  return <Dashboard />;
}
